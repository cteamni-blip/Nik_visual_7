Nik Visuals 3.6

Build tools:
- Loom 1.14-SNAPSHOT
- Gradle 9.2.1

Fixes from compile feedback:
- SlotTimerRenderer 2D translate/scale + remainingSeconds
- TrajectoryRenderer GlStateManager depth + trident + braces
- InventoryHudRenderer remainingSeconds
- InGameHudMixin getTickProgress
- NikVisualsClient RenderTickCounter
- TargetHUD head via reflection skin API + always show HP
- Menu smaller + logo instead of preview
- Swap saves/restores movement keys after freeze
