package com.nik.visuals.client.slot;

import com.nik.visuals.client.mixin.CooldownInstanceAccessor;
import com.nik.visuals.client.mixin.ItemCooldownsAccessor;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.ItemCooldownManager;
import net.minecraft.item.ItemStack;

import java.lang.reflect.Field;
import java.util.Map;

@Environment(EnvType.CLIENT)
public final class CooldownQuery {
    private CooldownQuery() {}

    public static int remainingSeconds(ClientPlayerEntity player, ItemStack stack, float partial) {
        if (player == null || stack == null || stack.isEmpty()) return -1;
        try {
            ItemCooldownManager mgr = player.getItemCooldownManager();
            float progress = mgr.getCooldownProgress(stack, partial);
            if (progress <= 0.001f) return -1;

            int tick = 0;
            int end = -1;
            int start = -1;

            if (mgr instanceof ItemCooldownsAccessor acc) {
                tick = acc.getTick();
                Map<?, ?> map = acc.getCooldowns();
                Object entry = findEntry(map, stack);
                if (entry instanceof CooldownInstanceAccessor ce) {
                    end = ce.getEndTick();
                    try { start = ce.getStartTick(); } catch (Throwable ignored) {}
                } else if (entry != null) {
                    end = readInt(entry, "endTick", "end", "field_19267");
                    start = readInt(entry, "startTick", "start", "field_19266");
                }
            }

            if (end > tick) {
                int rem = (int) Math.ceil((end - tick - partial) / 20.0);
                return rem < 1 ? -1 : rem;
            }
            if (start >= 0 && end > start) {
                int rem = (int) Math.ceil(progress * (end - start) / 20.0);
                return rem < 1 ? -1 : rem;
            }
            // progress-only fallback still often wrong for custom CDs — prefer hide under 1s
            int rem = (int) Math.ceil(progress * 5.0);
            return rem < 1 ? -1 : rem;
        } catch (Throwable t) {
            return -1;
        }
    }

    private static Object findEntry(Map<?, ?> map, ItemStack stack) {
        if (map == null || map.isEmpty()) return null;
        Object byItem = map.get(stack.getItem());
        if (byItem != null) return byItem;
        // try identifier / group keys by scanning single match
        for (Map.Entry<?, ?> e : map.entrySet()) {
            Object k = e.getKey();
            if (k != null && k.getClass().getName().contains("Item") && k.equals(stack.getItem())) {
                return e.getValue();
            }
        }
        if (map.size() == 1) return map.values().iterator().next();
        return null;
    }

    private static int readInt(Object o, String... names) {
        for (String n : names) {
            try {
                Field f = o.getClass().getDeclaredField(n);
                f.setAccessible(true);
                return f.getInt(o);
            } catch (Throwable ignored) {}
        }
        return -1;
    }
}
