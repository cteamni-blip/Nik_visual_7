package com.nik.visuals.client.render;

import com.nik.visuals.client.config.ModConfig;
import com.nik.visuals.client.slot.CooldownQuery;
import com.nik.visuals.client.theme.Style;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.ItemStack;

@Environment(EnvType.CLIENT)
public class InventoryHudRenderer {
    private int lastX, lastY, lastW, lastH;

    public int getLastX() { return lastX; }
    public int getLastY() { return lastY; }
    public int getLastW() { return lastW; }
    public int getLastH() { return lastH; }

    public void render(DrawContext g, float pt) {
        if (!ModConfig.inventoryHud && !ModConfig.layoutEdit) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity p = mc.player;
        if (p == null) return;
        if (mc.currentScreen != null && !ModConfig.layoutEdit) return;

        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();
        float scale = Math.max(0.5f, Math.min(1.8f, ModConfig.inventoryHudScale));
        int x = (int) (ModConfig.inventoryHudX * sw);
        int y = (int) (ModConfig.inventoryHudY * sh);
        int gridW = 166;
        int gridH = 58;
        lastX = x; lastY = y;
        lastW = (int) (gridW * scale);
        lastH = (int) (gridH * scale);

        g.getMatrices().pushMatrix();
        g.getMatrices().translate(x, y);
        g.getMatrices().scale(scale, scale);
        GuiDraw.glassPanel(g, 0, 0, gridW, gridH, 8, Style.PANEL, Style.ACCENT_GLOW);

        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                int slot = 9 + row * 9 + col;
                int sx = 2 + col * 18;
                int sy = 2 + row * 18;
                GuiDraw.fillRounded(g, sx, sy, 16, 16, 3, 0xAA0A0A0A);
                ItemStack stack = p.getInventory().getStack(slot);
                if (stack.isEmpty()) continue;
                g.drawItem(stack, sx, sy);
                g.drawStackOverlay(mc.textRenderer, stack, sx, sy);

                int seconds = CooldownQuery.remainingSeconds(p, stack, pt);
                if (seconds >= 1) {
                    String text = String.valueOf(seconds);
                    int color = seconds <= 2 ? 0xFFFF5555 : 0xFFFFFFFF;
                    float ts = 0.7f;
                    g.getMatrices().pushMatrix();
                    g.getMatrices().translate(sx + 1, sy + 1);
                    g.getMatrices().scale(ts, ts);
                    g.drawText(mc.textRenderer, text, 0, 0, color, true);
                    g.getMatrices().popMatrix();
                }
            }
        }
        g.getMatrices().popMatrix();
    }
}
