package com.nik.visuals.client.render;

import com.nik.visuals.client.config.ModConfig;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.ChargedProjectilesComponent;
import net.minecraft.item.BowItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import org.joml.Matrix4f;

import java.util.ArrayList;
import java.util.List;

@Environment(EnvType.CLIENT)
public class TrajectoryRenderer {
    public void renderWorld(MatrixStack poseStack, VertexConsumerProvider buffers, float pt) {
        if (!ModConfig.trajectory) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity player = mc.player;
        if (player == null || mc.world == null || buffers == null || poseStack == null || mc.currentScreen != null) {
            return;
        }

        Kind k = detect(player);
        if (k == null) return;

        // Visible through blocks (1.21.11)
        try {
            com.mojang.blaze3d.opengl.GlStateManager._depthMask(false);
            com.mojang.blaze3d.opengl.GlStateManager._disableDepthTest();
        } catch (Throwable ignored) {}

        try {
            Vec3d eye = player.getCameraPosVec(pt);
            Vec3d start = k.pearl ? eye.add(0.0, -0.1, 0.0) : eye;
            Vec3d look = player.getRotationVec(pt);
            List<Double> angles = k.multishot
                    ? List.of(-10.0, 0.0, 10.0)
                    : List.of(0.0);

            Vec3d cam = mc.gameRenderer.getCamera().getCameraPos();
            poseStack.push();
            Matrix4f m = poseStack.peek().getPositionMatrix();
            VertexConsumer lines;
            try {
                lines = buffers.getBuffer(RenderLayers.linesTranslucent());
            } catch (Throwable t) {
                lines = buffers.getBuffer(RenderLayers.lines());
            }

            for (double ang : angles) {
                SimResult res = simulate(player, start, rotateYaw(look, ang), k);
                if (res.path.size() < 2) continue;
                draw(lines, m, cam, res.path, res.hitEntity);
            }
            poseStack.pop();
        } finally {
            try {
                com.mojang.blaze3d.opengl.GlStateManager._depthMask(true);
                com.mojang.blaze3d.opengl.GlStateManager._enableDepthTest();
            } catch (Throwable ignored) {}
        }
    }

    private Kind detect(ClientPlayerEntity player) {
        ItemStack main = player.getMainHandStack();
        ItemStack off = player.getOffHandStack();

        if (main.isOf(Items.ENDER_PEARL) || off.isOf(Items.ENDER_PEARL)) {
            return new Kind(1.5, 0.03, 0.99f, false, true);
        }
        if (main.isOf(Items.TRIDENT) || off.isOf(Items.TRIDENT)) {
            // thrown trident when using (charge)
            if (player.isUsingItem() && player.getActiveItem().isOf(Items.TRIDENT)) {
                float use = Math.min(1f, player.getItemUseTime() / 10f);
                if (use > 0.1f) {
                    return new Kind(2.5 * use + 0.5, 0.05, 0.99f, false, false);
                }
            }
            // also show when just holding trident (short default arc)
            return new Kind(2.5, 0.05, 0.99f, false, false);
        }

        ItemStack xb = main.isOf(Items.CROSSBOW) ? main : (off.isOf(Items.CROSSBOW) ? off : null);
        if (xb != null) {
            ChargedProjectilesComponent ch = xb.get(DataComponentTypes.CHARGED_PROJECTILES);
            if (ch != null && !ch.isEmpty()) {
                return new Kind(3.15, 0.05, 0.99f, hasMulti(xb), false);
            }
        }
        if ((main.getItem() instanceof BowItem || off.getItem() instanceof BowItem)
                && player.isUsingItem()
                && player.getActiveItem().getItem() instanceof BowItem) {
            float pull = BowItem.getPullProgress(player.getItemUseTime());
            if (pull > 0.1f) {
                return new Kind(pull * 3.0, 0.05, 0.99f, false, false);
            }
        }
        if (main.isOf(Items.SNOWBALL) || off.isOf(Items.SNOWBALL)
                || main.isOf(Items.EGG) || off.isOf(Items.EGG)
                || main.isOf(Items.SPLASH_POTION) || off.isOf(Items.SPLASH_POTION)
                || main.isOf(Items.LINGERING_POTION) || off.isOf(Items.LINGERING_POTION)) {
            return new Kind(1.5, 0.03, 0.99f, false, true);
        }
        return null;
    }

    private boolean hasMulti(ItemStack stack) {
        try {
            var e = stack.get(DataComponentTypes.ENCHANTMENTS);
            if (e == null) return false;
            for (var en : e.getEnchantmentEntries()) {
                if (String.valueOf(en.getKey()).toLowerCase().contains("multishot")) return true;
            }
        } catch (Throwable ignored) {}
        return false;
    }

    private Vec3d rotateYaw(Vec3d dir, double degrees) {
        if (Math.abs(degrees) < 0.01) return dir;
        double rad = Math.toRadians(degrees);
        double cos = Math.cos(rad);
        double sin = Math.sin(rad);
        return new Vec3d(dir.x * cos - dir.z * sin, dir.y, dir.x * sin + dir.z * cos);
    }

    private SimResult simulate(ClientPlayerEntity player, Vec3d start, Vec3d dir, Kind k) {
        List<Vec3d> path = new ArrayList<>();
        Vec3d pos = start;
        Vec3d vel = dir.normalize().multiply(k.speed);
        boolean hitEntity = false;
        path.add(pos);
        for (int i = 0; i < 80; i++) {
            Vec3d next = pos.add(vel);
            BlockHitResult bhit = player.getEntityWorld().raycast(new RaycastContext(
                    pos, next, RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, player));
            EntityHitResult ehit = rayEntities(player, pos, next);
            if (ehit != null && (bhit.getType() == HitResult.Type.MISS
                    || ehit.getPos().squaredDistanceTo(pos) < bhit.getPos().squaredDistanceTo(pos))) {
                path.add(ehit.getPos());
                hitEntity = true;
                break;
            }
            if (bhit.getType() != HitResult.Type.MISS) {
                path.add(bhit.getPos());
                break;
            }
            pos = next;
            path.add(pos);
            vel = vel.multiply(k.drag).add(0, -k.gravity, 0);
        }
        return new SimResult(path, hitEntity);
    }

    private EntityHitResult rayEntities(ClientPlayerEntity player, Vec3d from, Vec3d to) {
        Vec3d d = to.subtract(from);
        Box box = player.getBoundingBox().stretch(d).expand(1.0);
        EntityHitResult best = null;
        double bestD = Double.MAX_VALUE;
        for (var e : player.getEntityWorld().getOtherEntities(player, box, ent -> ent.isAlive() && ent.canHit())) {
            Box eb = e.getBoundingBox().expand(0.3);
            var opt = eb.raycast(from, to);
            if (opt.isPresent()) {
                double dd = from.squaredDistanceTo(opt.get());
                if (dd < bestD) {
                    bestD = dd;
                    best = new EntityHitResult(e, opt.get());
                }
            }
        }
        return best;
    }

    private void draw(VertexConsumer lines, Matrix4f m, Vec3d cam, List<Vec3d> path, boolean hitEntity) {
        int argb = hitEntity ? 0xFFFF5555 : ModConfig.trajectoryColor;
        float r = ((argb >> 16) & 0xFF) / 255f;
        float g = ((argb >> 8) & 0xFF) / 255f;
        float b = (argb & 0xFF) / 255f;
        float a = 0.95f;
        float w = 3.5f;

        for (int i = 1; i < path.size(); i++) {
            Vec3d a0 = path.get(i - 1).subtract(cam);
            Vec3d a1 = path.get(i).subtract(cam);
            line(lines, m, a0, a1, r, g, b, a, w);
        }
        // end sphere (cross lines)
        Vec3d end = path.get(path.size() - 1).subtract(cam);
        double s = 0.12;
        line(lines, m, end.add(-s, 0, 0), end.add(s, 0, 0), r, g, b, a, w);
        line(lines, m, end.add(0, -s, 0), end.add(0, s, 0), r, g, b, a, w);
        line(lines, m, end.add(0, 0, -s), end.add(0, 0, s), r, g, b, a, w);
        double s2 = 0.08;
        line(lines, m, end.add(-s2, -s2, 0), end.add(s2, s2, 0), r, g, b, a, w);
        line(lines, m, end.add(-s2, s2, 0), end.add(s2, -s2, 0), r, g, b, a, w);
    }

    private void line(VertexConsumer v, Matrix4f m, Vec3d a, Vec3d b,
                      float r, float g, float bl, float al, float w) {
        float dx = (float) (b.x - a.x);
        float dy = (float) (b.y - a.y);
        float dz = (float) (b.z - a.z);
        float len = MathHelper.sqrt(dx * dx + dy * dy + dz * dz);
        if (len < 1e-6f) return;
        float nx = dx / len, ny = dy / len, nz = dz / len;
        v.vertex(m, (float) a.x, (float) a.y, (float) a.z).color(r, g, bl, al).normal(nx, ny, nz).lineWidth(w);
        v.vertex(m, (float) b.x, (float) b.y, (float) b.z).color(r, g, bl, al).normal(nx, ny, nz).lineWidth(w);
    }

    private record Kind(double speed, double gravity, float drag, boolean multishot, boolean pearl) {}
    private record SimResult(List<Vec3d> path, boolean hitEntity) {}
}
