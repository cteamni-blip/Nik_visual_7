package com.nik.visuals.client.render;

import com.nik.visuals.client.config.ModConfig;
import com.nik.visuals.client.theme.Anim;
import com.nik.visuals.client.theme.Style;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.MathHelper;

@Environment(EnvType.CLIENT)
public class TargetHUD {
    private LivingEntity target;
    private float appear;
    private float hpSmooth = 1f;
    private float flash;
    private int lastX, lastY, lastW = 148, lastH = 48;

    public int getLastX() { return lastX; }
    public int getLastY() { return lastY; }
    public int getLastW() { return lastW; }
    public int getLastH() { return lastH; }
    public int scaledW() { return lastW; }
    public int scaledH() { return lastH; }

    public void tick(MinecraftClient mc) {
        LivingEntity next = null;
        if (mc.crosshairTarget != null && mc.crosshairTarget.getType() == HitResult.Type.ENTITY) {
            Entity e = ((EntityHitResult) mc.crosshairTarget).getEntity();
            if (e instanceof LivingEntity le && le.isAlive()) next = le;
        }
        if (next != null) target = next;
        else if (target != null && (!target.isAlive() || (mc.player != null && target.squaredDistanceTo(mc.player) > 400))) {
            target = null;
        }

        boolean show = (ModConfig.targetHud && target != null) || ModConfig.layoutEdit;
        appear = Anim.approach(appear, show ? 1f : 0f, 0.16f);

        if (target != null) {
            float hp = realHealth(target) / Math.max(1f, realMax(target));
            float prev = hpSmooth;
            hpSmooth = Anim.approach(hpSmooth, MathHelper.clamp(hp, 0f, 1f), 0.12f);
            if (hpSmooth < prev - 0.02f) flash = 1f;
        }
        flash = Anim.approach(flash, 0f, 0.1f);
    }

    public void render(DrawContext g, float pt) {
        if (appear < 0.02f) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;

        float a = Anim.easeOutCubic(appear);
        float scale = MathHelper.clamp(ModConfig.targetHudScale, 0.7f, 1.5f);
        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();
        int bw = 148, bh = 48;
        int x = ModConfig.targetHudX < 0 ? sw / 2 - bw / 2 : (int) (ModConfig.targetHudX * sw);
        int y = ModConfig.targetHudX < 0 ? 14 : (int) (ModConfig.targetHudY * sh);
        lastX = x; lastY = y;
        lastW = (int) (bw * scale);
        lastH = (int) (bh * scale);

        g.getMatrices().pushMatrix();
        g.getMatrices().translate(x, y);
        g.getMatrices().scale(scale, scale);

        GuiDraw.glassPanel(g, 0, 0, bw, bh, 12, Style.alpha(Style.PANEL, a), Style.alpha(Style.ACCENT_GLOW, a));
        if (flash > 0.05f) {
            g.fill(2, 2, bw - 2, bh - 2, Style.solidAlpha(0xCC4444, (int) (45 * flash * a)));
        }

        String name = target != null ? target.getName().getString() : "Target";
        if (name.length() > 16) name = name.substring(0, 15) + "…";
        g.drawText(mc.textRenderer, name, 42, 9, Style.alpha(Style.TEXT, a), false);

        // head plate
        GuiDraw.fillRounded(g, 8, 10, 26, 26, 7, Style.alpha(Style.GLASS, a));
        g.fill(8, 10, 10, 36, Style.alpha(Style.ACCENT, a));
        drawHead(g, mc, 11, 12, 20, a);

        float hp = target != null ? hpSmooth : 0.7f;
        int barColor = hp > 0.5f ? Style.OK : (hp > 0.25f ? Style.WARN : Style.DANGER);
        GuiDraw.hpBar(g, 42, 26, 96, 9, hp, Style.alpha(barColor, a), Style.alpha(Style.TRACK_OFF, a));

        // Always show HP numbers (even if invisible)
        String hpText = target != null
                ? String.format("%.0f / %.0f", realHealth(target), realMax(target))
                : "— / —";
        g.drawText(mc.textRenderer, hpText, 42, 37, Style.alpha(Style.TEXT_DIM, a), false);

        if (ModConfig.showDistance && target != null) {
            String dist = String.format("%.1fm", mc.player.distanceTo(target));
            g.drawText(mc.textRenderer, dist, bw - 8 - mc.textRenderer.getWidth(dist), 9,
                    Style.alpha(Style.TEXT_DIM, a), false);
        }
        g.getMatrices().popMatrix();
    }

    private void drawHead(DrawContext g, MinecraftClient mc, int x, int y, int size, float a) {
        Identifier skin = null;
        try {
            if (target instanceof AbstractClientPlayerEntity pl) {
                skin = resolveSkin(pl);
            } else if (target != null && mc.getNetworkHandler() != null) {
                PlayerListEntry entry = mc.getNetworkHandler().getPlayerListEntry(target.getUuid());
                if (entry != null) skin = resolveSkin(entry);
            }
        } catch (Throwable ignored) {}

        if (skin != null) {
            try {
                g.drawTexture(RenderPipelines.GUI_TEXTURED, skin, x, y, 8f, 8f, size, size, 8, 8, 64, 64);
                g.drawTexture(RenderPipelines.GUI_TEXTURED, skin, x, y, 40f, 8f, size, size, 8, 8, 64, 64);
                return;
            } catch (Throwable ignored) {}
        }
        GuiDraw.fillSoftCircle(g, x + size / 2, y + size / 2, size / 3, Style.alpha(Style.ACCENT_DIM, a));
    }

    private static Identifier resolveSkin(Object holder) {
        // Try modern getSkinTextures().texture() and fallbacks via reflection for API drift
        try {
            var m = holder.getClass().getMethod("getSkinTextures");
            Object st = m.invoke(holder);
            if (st != null) {
                try {
                    var t = st.getClass().getMethod("texture");
                    Object id = t.invoke(st);
                    if (id instanceof Identifier i) return i;
                } catch (Throwable ignored) {}
                try {
                    var t = st.getClass().getMethod("body");
                    Object id = t.invoke(st);
                    if (id instanceof Identifier i) return i;
                } catch (Throwable ignored) {}
            }
        } catch (Throwable ignored) {}
        try {
            var m = holder.getClass().getMethod("getSkinTexture");
            Object id = m.invoke(holder);
            if (id instanceof Identifier i) return i;
        } catch (Throwable ignored) {}
        return null;
    }

    private static float realHealth(LivingEntity e) {
        float hp = e.getHealth();
        float abs = 0f;
        try { abs = e.getAbsorptionAmount(); } catch (Throwable ignored) {}
        float total = hp + abs;
        if (total > 2000f) total = hp; // insane plugin values
        return total;
    }

    private static float realMax(LivingEntity e) {
        try {
            float max = (float) e.getAttributeValue(EntityAttributes.MAX_HEALTH);
            if (max < 1f) max = e.getMaxHealth();
            return max;
        } catch (Throwable t) {
            return Math.max(1f, e.getMaxHealth());
        }
    }
}
